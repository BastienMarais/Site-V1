#define SDL_TTF_OK
