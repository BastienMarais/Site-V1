package vues;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import modele.Donnees;
import utilitaire.Constante;
import utilitaire.MethodesPourFichier;

/**
 * Cette classe affiche le panel contenant
 * tout le necessaire pour cr�er un fichier.
 * @author Vimont Adrien et Marais Bastien
 *
 */
public class PanelNouv extends JPanel implements ActionListener {
	
	
	GridBagLayout gestionnaireGrid = new GridBagLayout();
	GridBagConstraints contrainte = new GridBagConstraints();
	
	JLabel labelFile = new JLabel("Nom du fichier :");
	JTextField nomFile = new JTextField(10);
	JLabel extension = new JLabel(".obj");
	JTextField titre = new JTextField("Titre");
	JTextField titreX = new JTextField("Axe x");
	JTextField titreY = new JTextField("Axe y");
	JButton retour = new JButton("Retour");
	JButton creer = new JButton("Cr�er");
	JLabel notification = new JLabel();
	
	
	
	File newFile;
	Donnees newDonnees; 
	PanelAffichage pAff;
	
	public PanelNouv(PanelAffichage panelAffichage){
		
		pAff = panelAffichage;
		
		setLayout(gestionnaireGrid);
		setBackground(new Color(155,155,155));
		contrainte.fill=GridBagConstraints.BOTH;
		contrainte.insets = new Insets(10,10,10,10);
		
		// ajout de la premi�re ligne
		contrainte.gridx=0;
		contrainte.gridy=0;
		add(labelFile,contrainte);
		contrainte.gridx=1;
		add(nomFile,contrainte);
		contrainte.gridx=2;
		add(extension,contrainte);
		
		// ajout de la deuxi�me ligne 
		contrainte.gridx=0;
		contrainte.gridy=1;
		add(titre,contrainte);
		contrainte.gridx=1;
		add(titreX,contrainte);
		contrainte.gridx=2;
		add(titreY,contrainte);
				
		// ajout de la trois�me ligne
		contrainte.gridx=0;
		contrainte.gridy=2;
		add(retour,contrainte);
		contrainte.gridx=1;
		add(notification,contrainte);
		contrainte.gridx=2;
		add(creer,contrainte);
			
		// actionListener
		creer.addActionListener(this);
		retour.addActionListener(this);		
		
		
	}
	
	
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource()== retour){
			pAff.gestionnaireCartes.show(pAff, "acceuil");
		}
		if (evt.getSource()== creer){
			String fichier = nomFile.getText()+".obj";
			newFile = new File(Constante.REP_FILE+File.separator+fichier);
			newDonnees = new Donnees();
			newDonnees.setTitre(titre.getText());
			newDonnees.setTitreX(titreX.getText());
			newDonnees.setTitreY(titreY.getText());
			MethodesPourFichier.ecriture(newFile,newDonnees);
			notification.setText("Fichier cr��");
		}
		
	}

}
