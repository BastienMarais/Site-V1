package vues;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import modele.Donnees;
import modele.TableDonnees;

/**
 * Cette classe affiche le panel contenant
 * la table des donn�es.
 * @author Vimont Adrien et Marais Bastien
 *
 */
public class PanelTable extends JPanel{
	TableDonnees table;
	JScrollPane scroll;
	
	public PanelTable(Donnees donnees){

		table = new TableDonnees(donnees);
		scroll = new JScrollPane(table,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		add(scroll);
	}
}
