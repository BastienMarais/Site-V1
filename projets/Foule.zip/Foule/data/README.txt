Dans ce r�pertoire, les deux types de fichiers que vous aurez � utiliser:
  * plan - se charge � l'aide de la fonction charge_plan() fournie dans libfoule.
  * joueurs - fichier type des joueurs � charger si vous avez atteint l'objectif Foule.
    A vous d'�crire la fonction charge_joueurs() en vous inspirant de charge_plan().